# SA Calculator v99.00 — Semantic tool layout (card structure removal)

## Scope
- Replaced legacy tool-card class contracts across the tool HTML, shared CSS and app JavaScript with neutral semantic layout names.
- Removed legacy card class names from tool markup, including launcher tiles, tool form groups, result containers, finance/health field groups, date-event rows and favorites.
- Updated JavaScript selectors and dynamically generated favorite/date-event class names to the new semantic names.
- Added final theme-independent cardless surface rules. Focus-visible outlines, field controls, action buttons, result content, keypad, navigation and modal/dialog semantics remain intact.
- Kept Settings-specific cards and actual modal/dialog surfaces intact; these are not calculator-tool cards and retain their separate UX purpose.
- Preserved the existing GST placeholder single-render fix and all calculator field IDs/actions.

## Release identity
- App version: `1.99.14-v99.00`
- Android versionCode: `1099120`
- Service-worker cache: `sa-calculator-v99-00-semantic-tool-layout-v9900`
