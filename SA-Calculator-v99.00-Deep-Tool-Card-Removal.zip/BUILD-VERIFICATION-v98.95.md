# SA Calculator v98.95 — Audit and build verification

## Source identity
- App version: `1.99.09-v98.95`
- Android versionCode: `1099115`
- Service-worker cache: `sa-calculator-v98-95-all-tool-card-geometry-430x64-v9895`
- Input archive: `SA-Calculator-v98.95-All-Cards-430x64.zip`
- Supplied workflow YAML, `.github/workflows/main.yml`, `Android-Workflow-v98.95.yml`, and `sa-calculator-v98.95-android.yml` were byte-identical before documentation updates.

## Checks completed in this audit
- ZIP integrity: passed; 186 entries, 5,063,958 uncompressed bytes.
- Release regression suite: **162 passed, 0 failed** using the exact `npm run test:release` script.
- JavaScript syntax: passed for app.js, localization.js, theme-bootstrap.js, server.js, service-worker.js, prepare-android-web.mjs, and patch-android-native.mjs.
- Android web bundle: `npm run build:web` completed; 13 required assets verified.
- Root/www parity: 7/7 key source/build files byte-identical.
- HTML IDs: 316; duplicate IDs: 0.
- Workflow YAML: parsed successfully.
- Workflow test references: 22; missing references: 0.
- Package release-test references: 29; missing references: 0.
- CSS source brace counts: balanced in app.css and tool-reference-ui.css.
- Card geometry regression coverage: 430px maximum width, exactly 64px height, and narrow-screen fluid sizing are asserted by the release tests.
- Source/runtime version, Android version code, manifest version, and service-worker cache namespace were inspected for consistency.

## Findings and changes
- The supplied README contained stale v98.70/v98.93-era release identity text. It has been rewritten to describe v98.95 accurately.
- The release verification document has been refreshed to distinguish checks actually completed in this audit from checks not performed.
- No reproducible application-runtime defect was identified by the supplied v98.95 regression suite or static checks. Application JS/CSS behavior was therefore not changed speculatively.

## Not verified in this environment
- npm dependency installation did not complete before the environment command timed out; no package-lock was created and no dependency versions were altered.
- Capacitor sync, Gradle compilation, APK signing/installation, and remote GitHub Actions execution were not performed.
- No physical Android device screenshot/pixel measurement, touch-scroll test, accessibility pass, frame-rate measurement, or memory-pressure test was performed.
- Dense 64px cards can require internal scrolling; automated geometry checks do not establish that every card's full content is visible at once.

## Release conclusion
The source archive is structurally intact, its defined release regression suite passes, and the Android web bundle can be generated and parity-checked. An APK and physical-device quality claim require the outstanding Android CI/device checks above.
