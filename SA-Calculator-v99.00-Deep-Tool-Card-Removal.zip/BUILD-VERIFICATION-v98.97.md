# SA Calculator v98.98 — Build verification

## Automated results
- Release regression suite: **168 passed, 0 failed** (`npm test`).
- Dedicated v98.98 GST placeholder tests: 4 passed.
- JavaScript syntax: app, localization, theme bootstrap, server, service worker and Android preparation scripts passed `node --check`.
- Android web bundle: `npm run build:web` passed; 13 required assets verified.
- Root/Android web parity: 8 authoritative files byte-identical.
- YAML: 26 project workflow YAML files parsed; 1 unique content hash (mirrors byte-identical).
- HTML IDs: 316 unique; no duplicates.
- Release identity: `1.99.12-v98.98`; Android versionCode `1099118`.
- Source CSS and generated Android CSS synchronized.

## v98.98 correction
GST amount/rate fields now suppress the generic parent-level placeholder pseudo-element and retain the inline child placeholder renderer. This prevents duplicate placeholder paint beside entered digits when parent empty-state styling is stale. Existing GST keypad, caret, calculations and per-tool card geometry remain unchanged.

## Not performed
No physical Android WebView screenshot/pixel comparison, touch/scroll usability test, APK compilation/signing/installation, or remote GitHub Actions execution was performed in this environment. Automated tests do not prove zero lag or zero bugs on every device.
