# v98.88 build verification

- Release: `1.99.02-v98.88`
- Android versionCode: `1099108`
- Service worker cache: `sa-calculator-v98-88-gst-placeholder-layout-v9888`
- `node --check assets/js/app.js`: passed
- `node --check assets/js/localization.js`: passed
- `node scripts/prepare-android-web.mjs`: passed; 13 required assets verified
- `npm test`: **128 passed, 0 failed**
- YAML parse: 5 workflow copies parsed successfully
- Workflow copies: Android workflow, standalone YAML and `.github/workflows/main.yml` synchronized
- Root / `www/` asset synchronization: verified by release tests
- Remote GitHub Actions / APK build / physical Android device testing: not executed
