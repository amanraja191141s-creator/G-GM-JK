import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'www/assets/css/tool-reference-ui.css'),'utf8');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const workflow=fs.readFileSync(path.join(root,'.github/workflows/main.yml'),'utf8');
test('v98.81 release identity synchronized',()=>{
  assert.equal(pkg.version,'1.99.14-v99.00'); assert.equal(pkg.androidVersionCode,1099120);
  assert.ok(html.includes('1.99.14-v99.00')); assert.ok(workflow.includes('1.99.14-v99.00'));
});
test('GST, saving, tip, percentage and finance fields use shared loan-sized card geometry',()=>{
  for (const selector of ['.gst-amount-field','.gst-rate-field','.tool-field-row','.tip-video-form .reference-field','#screen-percent .tool-input-group .input-row']) assert.ok(css.includes(selector));
  assert.match(css,/--sa-field-height:88px/); assert.match(css,/--sa-field-icon:50px/); assert.match(css,/border-radius:22px/);
});
test('percentage reference screen has no seeded example values or alternate mode controls',()=>{
  assert.match(html,/id="pct-y"[^>]*><span class="input-text"><\/span>/);
  assert.match(html,/id="pct-x"[^>]*><span class="input-text"><\/span>/);
  assert.ok(css.includes('#screen-viewport #screen-percent .percent-mode-tabs'));
  assert.ok(css.includes('#screen-viewport #screen-percent #percent-panel-change'));
});
test('result panels are hidden until keypad calculation is committed',()=>{
  for (const id of ['screen-percent','screen-salestax','screen-savings','screen-tip']) assert.ok(css.includes(`#screen-viewport #${id}[data-tool-calculated="true"]`));
});
test('workflow validates matching version code and generated web bundle',()=>{
  assert.ok(workflow.includes('1099120')); assert.ok(workflow.includes('www/index.html'));
});
