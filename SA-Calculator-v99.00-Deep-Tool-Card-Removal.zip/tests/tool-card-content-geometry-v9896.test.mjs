import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync('index.html','utf8');
const css=fs.readFileSync('assets/css/tool-reference-ui.css','utf8');
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const tail=css.slice(css.indexOf('/* v98.96 — restore content-first'));
const tools=['currencies','units','discount','percent','salestax','agecalc','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','salary','savings','sip','tip','unitprice','worldtime'];
test('all 19 calculator tool screens remain present',()=>{ for(const id of tools) assert.match(html,new RegExp(`id=\"screen-${id}\"`)); });
test('v98.95 global 64px card cap is removed instead of hiding field content',()=>{
 assert.doesNotMatch(tail,/height\s*:\s*64px\s*!important/i);
 assert.doesNotMatch(tail,/max-height\s*:\s*64px\s*!important/i);
 assert.doesNotMatch(tail,/overflow-y\s*:\s*auto\s*!important/i);
 assert.match(css,/#screen-salestax \.tool-form-content[\s\S]*?min-height:145px !important/);
 assert.match(css,/#screen-currencies \.tool-field-row[\s\S]*?height:122px !important/);
 assert.match(css,/#screen-bodymetrics \.tool-field-group[\s\S]*?min-height:145px !important/);
});
test('shared card layer constrains width but does not override tool-specific heights',()=>{
 assert.match(tail,/max-width:430px !important/);
 assert.match(tail,/box-sizing:border-box !important/);
 assert.doesNotMatch(tail,/\b(?:height|min-height|max-height)\s*:/i);
});
test('responsive narrow screens cannot create horizontal card overflow',()=>{
 assert.match(tail,/@media \(max-width:380px\)/);
 assert.match(tail,/max-width:100% !important/);
});
test('source and Android web CSS remain synchronized',()=>{
 assert.equal(css,fs.readFileSync('www/assets/css/tool-reference-ui.css','utf8'));
});
test('release identity and service-worker cache are synchronized',()=>{
 assert.equal(pkg.version,'1.99.14-v99.00'); assert.equal(pkg.androidVersionCode,1099120);
 assert.match(html,/1\.99\.14-v99\.00/);
 assert.match(fs.readFileSync('assets/js/app.js','utf8'),/const APP_VERSION = '1\.99\.14-v99\.00'/);
 assert.match(fs.readFileSync('manifest.webmanifest','utf8'),/1\.99\.14-v99\.00/);
 assert.match(fs.readFileSync('service-worker.js','utf8'),/sa-calculator-v99-00-semantic-tool-layout-v9900/);
});
