# GST field boundary and alignment micro-audit — v98.83

## Screenshots inspected
Two Android screenshots at 709 × 1536 px were inspected. They show the same GST Calculator surface in two different presentations.

## Confirmed UI problems
1. The Original Amount entry showed a visible inset rectangular border in one screenshot.
2. The amount text/caret was centered rather than starting at the left edge.
3. The GST Rate entry showed an extra outlined rectangular input boundary.
4. The GST quick-rate controls were visually nested within a bordered card treatment.
5. The GST mode selector appeared twice in one screenshot: as the visible With GST / Without GST segmented buttons and as a second dropdown labelled With GST.
6. The amount/rate container surfaces used extra card borders and backgrounds that visually competed with the entry controls.

## Implemented corrections
- Scoped the cleanup to `#screen-salestax`; other calculator tools and their card systems are not globally restyled.
- Removed border, outline, shadow and decorative background from GST amount/rate containers and entry surfaces.
- Forced `#tax-orig` and `#tax-rate` text to `text-align:left`, `direction:ltr`, with left-justified entry content and caret.
- Removed decorative outlines from GST quick-rate pills and mode/place buttons while retaining their active/inactive fills and touch targets.
- Hid the duplicate native `#tax-mode` control while preserving it in the DOM for existing state synchronization.
- Kept icon tiles and the shared 4×4 keypad geometry; the keypad itself was not redesigned in this change.
- Added narrow-screen sizing rules for screens at or below 380 CSS px.

## Regression coverage
- Added `tests/gst-field-boundary-cleanup-v9883.test.mjs`.
- Release test command includes the new test entry.
- All workflow-required test paths are present and included in the release test command.

## Validation performed
- `npm test`: 103 tests passed, 0 failed.
- `node --check` passed for app.js, localization.js, service-worker.js, and the new test.
- Android web preparation passed; 13 required assets verified.
- Three Android workflow YAML files parsed successfully.
- All 18 release test paths exist; workflow-required test paths match the release test entry.
- Eight root/`www` mirror assets are byte-identical.

## Not claimed / remaining device validation
- No physical Android device or emulator visual test was run in this pass.
- No APK was built locally and no remote GitHub Actions run was triggered.
- Final font rendering, keyboard overlap, and touch feel should be confirmed on the target Android device after installing the generated APK.
