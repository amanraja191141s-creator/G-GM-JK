# SA Calculator v98.79 — Action-Time UI Geometry Hardening

- Rebuilt the shared tool keypad to the large four-row geometry visible in the supplied 720×1560 recordings.
- Synchronized keypad height with scroll padding so fields/results never sit underneath the dock.
- Rebuilt GST field/rate layout to eliminate the overlapping rate card and state controls.
- Fixed SIP inactive-tab contrast/readability.
- Fixed Saving Period `years` overflow/clipping.
- Introduced a fresh currency-pair storage namespace so a clean v98.79 install starts at USD → INR instead of inheriting an old FJD/other pair.
- Added action-time UI geometry regression coverage.
